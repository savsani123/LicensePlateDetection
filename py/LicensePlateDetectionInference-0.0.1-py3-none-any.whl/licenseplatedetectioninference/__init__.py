# remove warning message
import os
os.environ["TF_USE_LEGACY_KERAS"] = "1"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# required library
import cv2
import numpy as np
from os.path import splitext
from tensorflow.keras.models import model_from_json
from sklearn.preprocessing import LabelEncoder
import base64
import configparser
import io
from PIL import Image


class Label:
    def __init__(self, cl=-1, tl=np.array([0., 0.]), br=np.array([0., 0.]), prob=None):
        self.__tl = tl
        self.__br = br
        self.__cl = cl
        self.__prob = prob

    def __str__(self):
        return 'Class: %d, top left(x: %f, y: %f), bottom right(x: %f, y: %f)' % (
            self.__cl, self.__tl[0], self.__tl[1], self.__br[0], self.__br[1])

    def copy(self):
        return Label(self.__cl, self.__tl, self.__br)

    def wh(self): return self.__br - self.__tl

    def cc(self): return self.__tl + self.wh() / 2

    def tl(self): return self.__tl

    def br(self): return self.__br

    def tr(self): return np.array([self.__br[0], self.__tl[1]])

    def bl(self): return np.array([self.__tl[0], self.__br[1]])

    def cl(self): return self.__cl

    def area(self): return np.prod(self.wh())

    def prob(self): return self.__prob

    def set_class(self, cl):
        self.__cl = cl

    def set_tl(self, tl):
        self.__tl = tl

    def set_br(self, br):
        self.__br = br

    def set_wh(self, wh):
        cc = self.cc()
        self.__tl = cc - .5 * wh
        self.__br = cc + .5 * wh

    def set_prob(self, prob):
        self.__prob = prob


class DLabel(Label):
    def __init__(self, cl, pts, prob):
        self.pts = pts
        tl = np.amin(pts, axis=1)
        br = np.amax(pts, axis=1)
        Label.__init__(self, cl, tl, br, prob)


def getWH(shape):
    return np.array(shape[1::-1]).astype(float)


def IOU(tl1, br1, tl2, br2):
    wh1, wh2 = br1 - tl1, br2 - tl2
    assert ((wh1 >= 0).all() and (wh2 >= 0).all())

    intersection_wh = np.maximum(np.minimum(br1, br2) - np.maximum(tl1, tl2), 0)
    intersection_area = np.prod(intersection_wh)
    area1, area2 = (np.prod(wh1), np.prod(wh2))
    union_area = area1 + area2 - intersection_area
    return intersection_area / union_area


def IOU_labels(l1, l2):
    return IOU(l1.tl(), l1.br(), l2.tl(), l2.br())


def nms(Labels, iou_threshold=0.5):
    SelectedLabels = []
    Labels.sort(key=lambda l: l.prob(), reverse=True)

    for label in Labels:
        non_overlap = True
        for sel_label in SelectedLabels:
            if IOU_labels(label, sel_label) > iou_threshold:
                non_overlap = False
                break

        if non_overlap:
            SelectedLabels.append(label)
    return SelectedLabels


def find_T_matrix(pts, t_pts):
    A = np.zeros((8, 9))
    for i in range(0, 4):
        xi = pts[:, i]
        xil = t_pts[:, i]
        xi = xi.T

        A[i * 2, 3:6] = -xil[2] * xi
        A[i * 2, 6:] = xil[1] * xi
        A[i * 2 + 1, :3] = xil[2] * xi
        A[i * 2 + 1, 6:] = -xil[0] * xi

    [U, S, V] = np.linalg.svd(A)
    H = V[-1, :].reshape((3, 3))
    return H


def getRectPts(tlx, tly, brx, bry):
    return np.matrix([[tlx, brx, brx, tlx], [tly, tly, bry, bry], [1, 1, 1, 1]], dtype=float)


def normal(pts, side, mn, MN):
    pts_MN_center_mn = pts * side
    pts_MN = pts_MN_center_mn + mn.reshape((2, 1))
    pts_prop = pts_MN / MN.reshape((2, 1))
    return pts_prop


# Reconstruction function from predict value into plate crpoped from image
def reconstruct(I, Iresized, Yr, lp_threshold):
    # 4 max-pooling layers, stride = 2
    net_stride = 2 ** 4
    side = ((208 + 40) / 2) / net_stride

    # one line and two lines license plate size
    one_line = (470, 110)
    two_lines = (280, 200)

    Probs = Yr[..., 0]
    Affines = Yr[..., 2:]

    xx, yy = np.where(Probs > lp_threshold)
    # CNN input image size
    WH = getWH(Iresized.shape)
    # output feature map size
    MN = WH / net_stride

    vxx = vyy = 0.5  # alpha
    base = lambda vx, vy: np.matrix([[-vx, -vy, 1], [vx, -vy, 1], [vx, vy, 1], [-vx, vy, 1]]).T
    labels = []
    labels_frontal = []

    for i in range(len(xx)):
        x, y = xx[i], yy[i]
        affine = Affines[x, y]
        prob = Probs[x, y]

        mn = np.array([float(y) + 0.5, float(x) + 0.5])

        # affine transformation matrix
        A = np.reshape(affine, (2, 3))
        A[0, 0] = max(A[0, 0], 0)
        A[1, 1] = max(A[1, 1], 0)
        # identity transformation
        B = np.zeros((2, 3))
        B[0, 0] = max(A[0, 0], 0)
        B[1, 1] = max(A[1, 1], 0)

        pts = np.array(A * base(vxx, vyy))
        pts_frontal = np.array(B * base(vxx, vyy))

        pts_prop = normal(pts, side, mn, MN)
        frontal = normal(pts_frontal, side, mn, MN)

        labels.append(DLabel(0, pts_prop, prob))
        labels_frontal.append(DLabel(0, frontal, prob))

    final_labels = nms(labels, 0.1)
    final_labels_frontal = nms(labels_frontal, 0.1)

    # print(final_labels_frontal)
    assert final_labels_frontal, "No License plate is founded!"

    # LP size and type
    out_size, lp_type = (two_lines, 2) if (
                (final_labels_frontal[0].wh()[0] / final_labels_frontal[0].wh()[1]) < 1.7) else (one_line, 1)

    TLp = []
    Cor = []
    if len(final_labels):
        final_labels.sort(key=lambda x: x.prob(), reverse=True)
        for _, label in enumerate(final_labels):
            t_ptsh = getRectPts(0, 0, out_size[0], out_size[1])
            ptsh = np.concatenate((label.pts * getWH(I.shape).reshape((2, 1)), np.ones((1, 4))))
            H = find_T_matrix(ptsh, t_ptsh)
            Ilp = cv2.warpPerspective(I, H, out_size, borderValue=0)
            TLp.append(Ilp)
            Cor.append(ptsh)
    return final_labels, TLp, lp_type, Cor


def detect_lp(model, I, max_dim, lp_threshold):
    min_dim_img = min(I.shape[:2])
    factor = float(max_dim) / min_dim_img
    w, h = (np.array(I.shape[1::-1], dtype=float) * factor).astype(int).tolist()
    Iresized = cv2.resize(I, (w, h))
    T = Iresized.copy()
    T = T.reshape((1, T.shape[0], T.shape[1], T.shape[2]))
    # latency_file.writelines("inside detect_lp before model.predict:"+str(datetime.now().time()))
    # latency_file.writelines("\n")
    Yr = model.predict(T)
    # latency_file.writelines("inside detect_lp after model.predict:"+str(datetime.now().time()))
    # latency_file.writelines("\n")
    Yr = np.squeeze(Yr)
    # print(Yr.shape)
    L, TLp, lp_type, Cor = reconstruct(I, Iresized, Yr, lp_threshold)
    return L, TLp, lp_type, Cor



# config = configparser.ConfigParser()
# config.read('../config/config.ini')


# config.read('C:/Users/ayushi.jain18/PersonId/config.ini')

class LicensePlateDetection:
    def __init__(self, wpod_net_json, wpod_net_weight,
                 MobileNets_character_recognition_json, MobileNets_character_recognition_weight,
                 license_character_classes):
        # Part 1: Extract license plate from sample image
        # self.wpod_net = config['ModelDetails']['wpod_net']
        # self.wpod_net = wpod_net_json
        # wpod_net_path = "wpod-net.json"
        # wpod_net_path = self.wpod_net

        # path = splitext(wpod_net_path)[0]
        # with open('%s.json' % path, 'r') as json_file:
        with open(wpod_net_json, 'r') as json_file:
            model_json = json_file.read()
        self.wpod_net = model_from_json(model_json, custom_objects={})
        self.wpod_net.load_weights(wpod_net_weight)
        print("Loading LicensePlate wpod_net model successfully...")
        # wpod_net = load_model(wpod_net_path)

        MobileNets_character_recognition = MobileNets_character_recognition_json
        json_file = open(MobileNets_character_recognition, 'r')
        loaded_model_json = json_file.read()
        json_file.close()

        self.model = model_from_json(loaded_model_json)

        License_character_recognition_weight = MobileNets_character_recognition_weight
        # latency_file.writelines("License_character_recognition_weight load start:"+str(datetime.now().time()))
        # latency_file.writelines("\n")
        self.model.load_weights(License_character_recognition_weight)
        # latency_file.writelines("License_character_recognition_weight load end:"+str(datetime.now().time()))
        # latency_file.writelines("\n")

        self.labels = LabelEncoder()
        self.license_character_classes = license_character_classes

        print("[INFO] Model loaded successfully...")

    def load_model(self, path):
        try:
            path = splitext(path)[0]
            with open('%s.json' % path, 'r') as json_file:
                model_json = json_file.read()
            model = model_from_json(model_json, custom_objects={})
            model.load_weights('%s.h5' % path)
            print("Loading model successfully...")
            return model
        except Exception as e:
            print(e)

    def preprocess_image(self, image_path, resize=False):
        img = cv2.imread(image_path)

        # print("img",img)

        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img / 255
        if resize:
            img = cv2.resize(img, (224, 224))
        return img

    def get_plate(self, image_path, Dmax=608, Dmin=608):
        ##wpod_net = config['ModelDetails']['wpod_net']
        # wpod_net_path = "wpod-net.json"
        ##wpod_net_path = wpod_net

        # latency_file = open(r"C:/WorkArea/Services/Python/logs/license_plate_latency.log","a")
        # latency_file.writelines("get_plate load_model start:"+str(datetime.now().time()))
        # latency_file.writelines("\n")
        ##wpod_net = load_model(wpod_net_path)
        # latency_file.writelines("get_plate load_model end:"+str(datetime.now().time()))
        # latency_file.writelines("\n")
        # vehicle = preprocess_image(image_path)
        vehicle = image_path
        vehicle = vehicle / 255

        # print("vehicle", vehicle)
        dim = vehicle.shape[:2]
        ratio = float(max(vehicle.shape[:2])) / min(vehicle.shape[:2])
        side = int(ratio * Dmin)
        bound_dim = min(side, Dmax)
        # latency_file.writelines("get_plate detect_lp start:"+str(datetime.now().time()))
        # latency_file.writelines("\n")
        aq, LpImg, aw, cor = detect_lp(self.wpod_net, vehicle, bound_dim, lp_threshold=0.5)
        # latency_file.writelines("get_plate detect_lp end:"+str(datetime.now().time()))
        # latency_file.writelines("\n")
        # latency_file.close()
        # print('vehicle, LpImg, cor', vehicle, LpImg, cor)

        return vehicle, LpImg, cor, dim

    # Create sort_contours() function to grab the contour of each digit from left to right
    def sort_contours(self, cnts, reverse=False):
        i = 0
        boundingBoxes = [cv2.boundingRect(c) for c in cnts]
        (cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
                                            key=lambda b: b[1][i], reverse=reverse))
        return cnts

    # pre-processing input images and pedict with model
    def predict_from_model(self, image, model, labels):
        image = cv2.resize(image, (80, 80))
        image = np.stack((image,) * 3, axis=-1)
        prediction = labels.inverse_transform([np.argmax(model.predict(image[np.newaxis, :]))])

        return prediction

    def executeModel(self, base64_image, confidence_threshold, req_data):
        try:
            final_result = {}
            final_output = []
            output = {}
            # latency_file = open(r"C:/WorkArea/Services/Python/logs/license_plate_latency.log","a")
            # latency_file.writelines("License plate API Start:"+str(datetime.now().time()))
            # latency_file.writelines("\n")
            # latency_file.close()
            # test_image_path = req_data['base64_image']

            print("type(base64_image)", type(base64_image))
            if type(base64_image) != str:
                print("raising TypoError")
                raise TypeError
            '''
            imgdata = base64.b64decode(test_image_path)
            filename = 'some_image.jpg'  
            with open(filename, 'wb') as f:
                f.write(imgdata)
            '''
            image = Image.open(io.BytesIO(base64.b64decode(base64_image)))
            image = image.convert('RGB') if image.mode != 'RGB' else image
            filename = np.array(image)

            # latency_file.writelines("get_plate function call start:"+str(datetime.now().time()))
            # latency_file.writelines("\n")
            vehicle, LpImg, cor, dim = self.get_plate(filename)
            # latency_file.writelines("get_plate function call end:"+str(datetime.now().time()))
            # latency_file.writelines("\n")

            # w = dim[1]
            # h = dim[0]
            x_coordinates = cor[0][0]
            y_coordinates = cor[0][1]
            # print('h,w of img',h,w)
            # print('dim',dim)
            x = x_coordinates[0] / dim[1]
            y = y_coordinates[0] / dim[0]

            h = (y_coordinates[2] - y_coordinates[0]) / dim[0]
            w = (x_coordinates[1] - x_coordinates[0]) / dim[1]
            x = round(x, 3)
            y = round(y, 3)
            h = round(h, 3)
            w = round(w, 3)
            # print('x,y,h,w of img', x_coordinates[0],y_coordinates[0],y_coordinates[2]-y_coordinates[0],x_coordinates[1]-x_coordinates[0])
            # print("x,y,h,w", x,y,h,w)
            dm = {'X': x, 'Y': y, 'H': h, 'W': w}

            output['Dm'] = dm
            # print('final vehicle, LpImg, cor', vehicle, LpImg, cor)

            ## Part 2: Segementing license characters

            if (len(LpImg)):  # check if there is at least one license image
                # Scales, calculates absolute values, and converts the result to 8-bit.
                plate_image = cv2.convertScaleAbs(LpImg[0], alpha=(255.0))

                # convert to grayscale and blur the image
                gray = cv2.cvtColor(plate_image, cv2.COLOR_BGR2GRAY)
                blur = cv2.GaussianBlur(gray, (7, 7), 0)

                # Applied inversed thresh_binary
                binary = cv2.threshold(blur, 180, 255,
                                       cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

                kernel3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
                thre_mor = cv2.morphologyEx(binary, cv2.MORPH_DILATE, kernel3)

            cont, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # creat a copy version "test_roi" of plat_image to draw bounding box
            test_roi = plate_image.copy()

            # Initialize a list which will be used to append charater image
            crop_characters = []

            # define standard width and height of character
            digit_w, digit_h = 30, 60

            for c in self.sort_contours(cont):
                (x, y, w, h) = cv2.boundingRect(c)
                ratio = h / w
                if 1 <= ratio <= 3.5:  # Only select contour with defined ratio
                    if h / plate_image.shape[
                        0] >= 0.5:  # Select contour which has the height larger than 50% of the plate
                        # Draw bounding box arroung digit number
                        cv2.rectangle(test_roi, (x, y), (x + w, y + h), (0, 255, 0), 2)

                        # Sperate number and gibe prediction
                        curr_num = thre_mor[y:y + h, x:x + w]
                        curr_num = cv2.resize(curr_num, dsize=(digit_w, digit_h))
                        _, curr_num = cv2.threshold(curr_num, 220, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                        crop_characters.append(curr_num)

            # Load pre-trained MobileNets model and predict

            # Load model architecture, weight and labels
            # MobileNets_character_recognition = config['ModelDetails']['MobileNets_character_recognition']
            # json_file = open(MobileNets_character_recognition, 'r')
            # loaded_model_json = json_file.read()
            # json_file.close()
            # latency_file.writelines("model_from_json start:"+str(datetime.now().time()))
            # latency_file.writelines("\n")
            # model = model_from_json(loaded_model_json)
            # latency_file.writelines("model_from_json end:"+str(datetime.now().time()))
            # latency_file.writelines("\n")

            # labels = LabelEncoder()
            # license_character_classes = config['ModelDetails']['license_character_classes']

            self.labels.classes_ = np.load(self.license_character_classes)
            print("[INFO] Labels loaded successfully...")

            final_string = ''
            # latency_file.writelines("predict_from_model start:"+str(datetime.now().time()))
            # latency_file.writelines("\n")
            for i, character in enumerate(crop_characters):
                title = np.array2string(self.predict_from_model(character, self.model, self.labels))
                final_string += title.strip("'[]")
            # latency_file.writelines("predict_from_model end:"+str(datetime.now().time()))
            # latency_file.writelines("\n")

            print(final_string)

            if len(final_string) > 0:
                vehicle_no = final_string

                output['Lb'] = vehicle_no
                output['Cs'] = ''
                output['Kp'] = {}
                output['Info'] = ''
                output['Uid'] = ''
                output['Nobj'] = ''

                final_output.append(output)

                final_result['Fs'] = final_output

                final_result['RC'] = "200"
                final_result["RM"] = "Success"
                # latency_file.writelines("License plate API end:"+str(datetime.now().time()))
                # latency_file.writelines("\n")
                # latency_file.close()
                return final_result
            else:

                output['Lb'] = "NA"
                output['Cs'] = ''
                output['Kp'] = {}
                output['Info'] = ''
                output['Uid'] = ''
                output['Nobj'] = ''
                final_output.append(output)
                final_result['Objects'] = final_output

                final_result["RC"] = "220"
                final_result["RM"] = "plate is detected but detection of characters is failed"

                return (final_result)

        except KeyError:
            '''dm  = {'X':'','Y':'','H':'','W':''}
            output['Dm'] = dm
            output['Lb'] = "null"
            output['Cs'] = 'null'
            final_output.append(output)'''
            final_result['Objects'] = final_output

            final_result['RC'] = "412"
            final_result["RM"] = 'Input Json invalid Dictionary Key Value'

            return (final_result)

        except AssertionError:
            '''dm  = {'X':'NA','Y':'NA','H':'NA','W':'NA'}
            output['Dm'] = dm
            output['Lb'] = "NA"
            output['Cs'] = 'NA'
            final_output.append(output)'''
            final_result['Objects'] = final_output

            final_result['RC'] = "221"
            final_result["RM"] = 'Number plate not detected'

            return (final_result)

        except TypeError:
            '''dm  = {'X':'','Y':'','H':'','W':''}
            output['Dm'] = dm
            output['Lb'] = "null"
            output['Cs'] = 'null'
            final_output.append(output)'''
            final_result['Objects'] = final_output

            final_result['RC'] = "414"
            final_result["RM"] = 'Invalid Frame ID Format'

            return (final_result)

        except Exception as e:
            print(e)
            '''dm  = {'X':'','Y':'','H':'','W':''}
            output['Dm'] = dm
            output['Lb'] = "null"
            output['Cs'] = 'null'
            final_output.append(output)'''
            final_result['Objects'] = final_output

            final_result['RC'] = "415"
            final_result["RM"] = str(e)

            return (final_result)
